<footer>
       <p>Por Alejandro Sánchez Galvín</p>
</footer>