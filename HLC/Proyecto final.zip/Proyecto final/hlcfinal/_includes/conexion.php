<?php
    //$conexion= mysqli_connect("localhost","hlcfinal","root","hlcfinal");
    $conexion= mysqli_connect("mysql.hostinger.es","u852589395_yo","rootroot","u852589395_prueb");
    mysqli_set_charset($conexion,"utf8");
?>