package es.iessaladillo.jgrana.docencia.ejemplofachada.model.j2sefacade.actions;

public interface Action {

	public Object execute();
}
