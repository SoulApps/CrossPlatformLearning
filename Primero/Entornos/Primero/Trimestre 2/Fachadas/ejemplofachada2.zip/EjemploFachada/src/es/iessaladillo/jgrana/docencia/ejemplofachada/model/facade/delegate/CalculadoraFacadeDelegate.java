package es.iessaladillo.jgrana.docencia.ejemplofachada.model.facade.delegate;

public interface CalculadoraFacadeDelegate {

	Integer sumar(Integer x, Integer y);
	Integer restar(Integer x, Integer y);
	Integer factorial(Integer x);
	
}
