package potencias;

public class Object {
	public PotenciaSimple potencia;

	public Object(PotenciaSimple potencia) {
		this.potencia = potencia;
	}
}