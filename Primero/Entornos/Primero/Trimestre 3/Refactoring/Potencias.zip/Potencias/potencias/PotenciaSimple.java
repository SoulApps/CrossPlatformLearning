package potencias;
public class PotenciaSimple {

	protected int base;
	protected int exponente;

	public PotenciaSimple() {
		super();
	}

	public int getBase() {
		return base;
	}

	public void setBase(int base) {
		this.base = base;
	}

	public int getExponente() {
		return exponente;
	}

	public void setExponente(int exponente) {
		this.exponente = exponente;
	}

}