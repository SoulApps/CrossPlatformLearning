package interfaz;

public interface Accion {

	public abstract Object ejecutar();
}
