package actions;

import banco.Cuenta;

public class TransferirDineroAction implements Action {
	
	Cuenta deaqui;
	Cuenta aaqui;
	double transferencia;
	
	public TransferirDineroAction(Cuenta deaqui, Cuenta aaqui,double transferencia){
		this.deaqui=deaqui;
		this.aaqui=aaqui;
		this.transferencia=transferencia;
	}
	public Object execute() {
		deaqui.setSaldo(deaqui.getSaldo()-transferencia);
		aaqui.setSaldo(aaqui.getSaldo()+transferencia);
		return deaqui;
	}

}
