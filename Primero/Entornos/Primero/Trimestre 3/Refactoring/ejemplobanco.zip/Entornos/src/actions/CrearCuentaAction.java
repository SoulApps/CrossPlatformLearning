package actions;

import banco.Cuenta;

public class CrearCuentaAction implements Action{

	double saldoInicial;
	
	public CrearCuentaAction(double saldoInicial){
		this.saldoInicial=saldoInicial;
	}
	
	public Object execute() {
		Cuenta micuenta=new Cuenta ();
		micuenta.setSaldo(saldoInicial);
		return micuenta;
	}
}
