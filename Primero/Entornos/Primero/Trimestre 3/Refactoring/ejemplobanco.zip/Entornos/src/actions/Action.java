package actions;

public interface Action {

	public abstract Object execute();
}
