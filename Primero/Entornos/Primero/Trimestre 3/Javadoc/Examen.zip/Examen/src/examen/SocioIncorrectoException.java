package examen;

/**
 * Excepci�n que impide la introducci�n de un nif incorrecto
 * @author Alejandro
 *
 */
public class SocioIncorrectoException extends Exception{

	/**
	 * Constructor de la excepci�n SocioIncorrectoException
	 * @param mensaje Es el mensaje de la excepci�n
	 */
	public SocioIncorrectoException(String mensaje){
		super(mensaje);
	}
}
