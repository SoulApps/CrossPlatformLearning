package examen;

import java.text.SimpleDateFormat;

/**
 * Clase SocioIndividual
 * @author Alejandro
 *
 */
public class SocioIndividual extends Socio{
	
	/**
	 * Constructor de la clase SocioIndividual
	 * @throws SocioIncorrectoException Controla que el nif se introduzca correctamente
	 */
	public SocioIndividual() throws SocioIncorrectoException{
		super();
	}
	
	/**
	 * Constructor de la clase SocioIndividual
	 * @param nombre Es el nombre a introducir
	 * @param nif Es el nif a introducir
	 * @throws SocioIncorrectoException Lanza la excepci�n si se introduce un nif incorrecto
	 */
	public SocioIndividual(String nombre, String nif) throws SocioIncorrectoException{
		this.nombre=nombre;
		setNif(nif);
	}
	
	
	public double calcularCuotaBasica(){
		if(numAct>Constantes.LIMACTIND)
			base=Constantes.MES/Constantes.DESCUENTOIND;
		else
			base=Constantes.MES;
		return base;	
	}
	
	
	public double calcularCuotaActividades(){
		act=numAct*act;
		return act;
	}

	
	public void registrarActividades(int numAct){
		this.numAct=numAct;
	}

	/**
	 * equals
	 */
	public boolean equals(Object o){
		boolean igual=false;
		
		if(o instanceof SocioIndividual){
			if(nombre.equals(((SocioIndividual)o).nombre) && (nif.equals(((SocioIndividual)o).nif)) && (fecha.equals(((SocioIndividual)o).fecha))){
				igual=true;
			}
		}
		return igual;
	}
	
	/**
	 * clone
	 */
	public Object clone() {

		return super.clone();
	}

	/**
	 * toString
	 */
	public String toString(){
		SimpleDateFormat formato = new SimpleDateFormat("dd/MMMM/yyyy");
		return "[Nombre: "+nombre+" Nif: "+nif+" Fecha de alta: "+formato.format(fecha)+"]";
	}
}
