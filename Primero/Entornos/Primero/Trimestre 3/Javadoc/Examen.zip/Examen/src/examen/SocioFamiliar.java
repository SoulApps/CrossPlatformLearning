package examen;

import java.text.SimpleDateFormat;
import java.util.Arrays;

/**
 * Clase SocioFamiliar
 * @author Alejandro
 *
 */
public class SocioFamiliar extends Socio{
	
	protected Familiares familiar[]=new Familiares[5];
	
	/**
	 * Constructor de la clase SocioFamiliar
	 * @throws SocioIncorrectoException Controla que el nif se introduzca correctamente
	 */
	public SocioFamiliar() throws SocioIncorrectoException{
		super();
		
	}
	
	/**
	 * Constructor de la clase SocioFamiliar
	 * @param nombre Es el nombre a introducir
	 * @param nif Es el nif a introducir
	 * @throws SocioIncorrectoException Controla que el nif se introduzca correctamente
	 */
	public SocioFamiliar(String nombre, String nif) throws SocioIncorrectoException{
		this.nombre=nombre;
		setNif(nif);
	}
	
	
	public double calcularCuotaBasica(){
		return base;
	}

	
	public double calcularCuotaActividades(){
		act=familiar.length*Constantes.ACTIVIDAD/Constantes.DESCUENTOFAM;
		return act;
	}
	
	
	public void registrarActividades(int numAct){
		this.numAct+=numAct;
	}
	
	//Clase interna familiar
		
		/**
		 * Clase interna Familiares
		 * @author Alejandro
		 *
		 */
		public class Familiares implements Cloneable{

			private String nombre;
			private int numAct;
			
			/**
			 * Constructor de la clase interna Familiares
			 * @param nombre Es el nombre a introducir
			 */
			public Familiares(String nombre){
				this.nombre=nombre;
			}
			
			/**
			 * Getter del nombre
			 * @return String Devuelve el nombre
			 */
			public String getNombre(){
				return nombre;
			}
			
			/**
			 * Setter del nombre
			 * @param nombre Es el nombre a cambiar
			 */
			public void setNombre(String nombre){
				this.nombre=nombre;
			}
			
			/**
			 * M�todo para registrar actividades
			 * @param numAct Es el n�mero de actividades a introducir
			 */
			public void registrarActividades(int numAct){
				this.numAct=numAct;
			}
			
			/**
			 * equals
			 */
			public boolean equals(Object o){
				boolean igual=false;
				
				if(o instanceof Familiares){
					if(nombre.equals(((Familiares)o).nombre) && (numAct==(((Familiares)o).numAct))){
						igual=true;
					}
				}
				return igual;
			}
			
			/**
			 * clone
			 */
			public Object clone() {
				Familiares f;
				
				try{
					
					f= (Familiares) super.clone();
					
				}catch(CloneNotSupportedException e){
					
					f = null;
				}
				
				return f;
			}

			/**
			 * toString
			 */
			public String toString(){
				return "[Nombre: "+nombre+" N�mero de actividades: "+numAct+"]";
			}
		}
		//Fin de la clase interna
		
		/**
		 * equals
		 */
		public boolean equals(Object o){
			boolean igual=false;
			
			if(o instanceof SocioFamiliar){
				if(nombre.equals(((SocioFamiliar)o).nombre) && (nif.equals(((SocioFamiliar)o).nif))
						&& (fecha.equals(((SocioFamiliar)o).fecha))
						&& Arrays.equals(familiar, ((SocioFamiliar)o).familiar)){
					igual=true;
				}
			}
			return igual;
		}
		
		/**
		 * clone
		 */
		public Object clone() {

			SocioFamiliar s;
			byte i;
			
			s=(SocioFamiliar) super.clone();
			s.familiar=familiar.clone();
				
			for(i=0;i<familiar.length;i++){
				if(familiar[i]!=null){
					s.familiar[i]=(Familiares) familiar[i].clone();
				}
			}
			return s;
		}

		/**
		 * toString
		 */
		public String toString(){
			SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
			String socFam="";
			int numFam=0;
			int i;
			
			for(i=0; i<familiar.length; i++){
				if(familiar[i]!=null){
					socFam+=familiar[i].toString();
					numFam++;
				}
			}
			return "[Nombre: "+nombre+" Nif: "+nif+" Fecha de alta: "+formato.format(fecha)+" N�mero de familiares: "+familiar.length+"]";
		}
}
