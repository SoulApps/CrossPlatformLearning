package examen;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Clase abstracta Socio
 * @author Alejandro
 *
 */
public abstract class Socio implements Pagos, Cloneable, Actividades{
	
	protected String nombre;
	protected String nif;
	protected Date fecha;
	protected double cuota;
	protected int numAct;
	protected double base=Constantes.MES;
	protected double act=Constantes.ACTIVIDAD;
	
	
	/**
	 * Excepci�n que impide introducir un nif incorrecto
	 * @throws SocioIncorrectoException Controla que el nif se introduzca correctamente
	 */
	public Socio() throws SocioIncorrectoException{
		
		nombre="Nombre";
		//nif="12345678A";
		fecha=new Date();
		
	}
	
	/**
	 * Constructor de la clase Socio
	 * @param nombre Es el nombre a introducir
	 * @param nif	Es el nif a introducir
	 * @throws SocioIncorrectoException Controla que el nif se introduzca correctamente
	 */
	public Socio(String nombre,String nif) throws SocioIncorrectoException{
		this.nombre=nombre;
		setNif(nif);
	}

	/**
	 * Matches de nif
	 * @param nif Es el nif a comprobar
	 * @throws SocioIncorrectoException Controla que el nif se introduzca correctamente
	 */
	public void setNif(String nif) throws SocioIncorrectoException{
		if (nif.matches("[0-9]{8}[A-Z]{1}"))
			this.nif=nif;
		else 
			throw new SocioIncorrectoException("El nif del socio no es correcto");
	}
	
	/**
	 * M�todo para calcular cuota mensual
	 */
	public final double calcularCuotaMensual(){
		return calcularCuotaBasica()+calcularCuotaActividades();
	}
	
	/**
	 * M�todo para calcular la cuota b�sica mensual
	 * @return double Devuelve un double
	 */
	public abstract double calcularCuotaBasica();
	
	/**
	 * M�todo para calcular la cuota mensual de las actividades
	 * @return double Devuelve un double
	 */
	public abstract double calcularCuotaActividades();
	
	/**
	 * M�todo para registrar actividades
	 */
	public abstract void registrarActividades(int numAct);
	
	/**
	 * clone
	 */
	public Object clone(){
		
		Socio s;
		
		try{
			
			s= (Socio) super.clone();
			s.fecha= (Date) fecha.clone();
			
		}catch(CloneNotSupportedException e){
			
			s = null;
		}
		
		return s;
	}
	
	/**
	 * toString
	 */
	public String toString(){
		SimpleDateFormat formato = new SimpleDateFormat("dd/MMMM/yyyy");
		return "[Nombre: "+nombre+" Nif: "+nif+" Fecha de alta: "+formato.format(fecha)+"]";
	}
	
	/**
	 * equals
	 */
	public boolean equals (Object o){
		boolean igual=false;
		
		if(o instanceof Socio){
			if(nombre.equals(((Socio)o).nombre) && (nif.equals(((Socio)o).nif)) && (fecha.equals(((Socio)o).fecha))){
				igual=true;
			}
		}
		return igual;
		
	}
}
