package examen;

/**
 * Interfaz Pagos
 * @author Alejandro
 *
 */
public interface Pagos {

	/**
	 * M�todo para calcular la cuota mensual
	 * @return double Devuelve un double
	 */
	public double calcularCuotaMensual();
	
}
