package examen;

/**
 * Enum Familiar
 * @author Alejandro
 *
 */
public enum Familiar {
	PADRE, MADRE, HERMANO, OTRO;
}
