package examen;

/**
 * Interfaz Actividades
 * @author Alejandro
 *
 */
public interface Actividades {

	/**
	 * M�todo para registrar actividades
	 * @param numAct Es el n�mero de actividades a registrar
	 */
	public void registrarActividades(int numAct);
	
}
