package examen;

/**
 * Constantes
 * @author Alejandro
 *
 */
public class Constantes {

	protected final static double MES=40;
	protected final static double ACTIVIDAD=2;
	protected final static double LIMACTIND=20;
	protected final static double DESCUENTOIND=1.20;
	protected final static double DESCUENTOFAM=1.10;
}
