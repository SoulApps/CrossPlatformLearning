
public enum Vinculo {
	MADRE,PADRE,HERMANO,OTRO
}
