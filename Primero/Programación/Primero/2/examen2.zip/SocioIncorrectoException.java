
public class SocioIncorrectoException extends Exception {
	
	private static final long serialVersionUID = 1L;

	public SocioIncorrectoException(String mensaje){
		super(mensaje);
	}
}
