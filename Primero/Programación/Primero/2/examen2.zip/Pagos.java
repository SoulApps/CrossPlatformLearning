
public interface Pagos {
	float calcularCuotaMensual();
}
