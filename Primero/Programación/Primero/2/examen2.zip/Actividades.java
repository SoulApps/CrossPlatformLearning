
public interface Actividades {
	void registrarActividades(int numActividades);
}
